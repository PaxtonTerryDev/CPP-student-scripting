enum DegreeProgram
{
    SECURITY,
    NETWORK,
    SOFTWARE
};